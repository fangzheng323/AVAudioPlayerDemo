//
//  TestProtocol.h
//  AVAudioPlayerDemo
//
//  Created by 方正 on 16/8/29.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^block)(NSArray *array,NSError *error);

@protocol AutoProtocolDelegate <NSObject>

- (void)doSomeThingWithBlok:(block)block;

@end

@interface TestProtocol : NSObject

@property (strong ,nonatomic) NSMutableArray *array;
@property (nonatomic,weak) id<AutoProtocolDelegate> delegate;
- (void) test;
@end
