//
//  TestPlayerViewController.m
//  AVAudioPlayerDemo
//
//  Created by 方正 on 16/9/2.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import "TestPlayerViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#define kRecordAudioFile @"myRecord.caf"


@interface TestPlayerViewController ()<AVAudioRecorderDelegate>

@property (nonatomic ,strong) AVAudioRecorder *audioRecorder;
@property (nonatomic ,strong) AVAudioPlayer *audioPlayer;
@property (nonatomic ,strong) NSTimer *timer;
@property (weak, nonatomic) IBOutlet UIProgressView *audioPower;


@end

@implementation TestPlayerViewController
//- (instancetype)init
//{
//    self = [UIStoryBoardNamed(StotyboardName) instantiateViewControllerWithIdentifier:@"ULCMessageDeveloppingViewController"];
//    if (self) {
//        
//    }
//    return self;
//    
//}
//- (instancetype)init
//{
//    self = [[UIStoryboard storyboardWithName:@"ULCMessageStoryboard" bundle:[NSBundle bundleWithURL:[[NSBundle mainBundle] URLForResource:@"ULCMessageResource" withExtension:@"bundle"]]] instantiateViewControllerWithIdentifier:@"ULCMessageDeveloppingViewController"];
//    if (self) {
//
//    }
//    return self;
//}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setAudioSession];
}
- (void)setAudioSession{
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [audioSession setActive:YES error:nil];
}
-(NSURL *)getSavePath{
    NSString *urlStr=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    urlStr=[urlStr stringByAppendingPathComponent:kRecordAudioFile];
    NSLog(@"file path:%@",urlStr);
    NSURL *url=[NSURL fileURLWithPath:urlStr];
    return url;
}
//录音设置
- (NSDictionary*)getAudioSetting{
    NSMutableDictionary *diction = [[NSMutableDictionary alloc] init];
    [diction setObject:@(kAudioFormatLinearPCM) forKey:AVFormatIDKey];//录音格式
    [diction setObject:@(8000) forKey:AVSampleRateKey];
    [diction setObject:@(1) forKey:AVNumberOfChannelsKey];
    [diction setObject:@(8) forKey:AVLinearPCMBitDepthKey];
    [diction setObject:@(YES) forKey:AVLinearPCMIsFloatKey];
    return diction;
}

- (AVAudioRecorder*)audioRecorder{
    if (!_audioRecorder) {
        NSError *error = nil;
        _audioRecorder = [[AVAudioRecorder alloc] initWithURL:[self getSavePath] settings:[self getAudioSetting] error:&error];
        _audioRecorder.delegate = self;
        _audioRecorder.meteringEnabled = YES;
        if (error) {
            NSLog(@"error==%@",error.localizedDescription);
            return nil;
        }
    }
    return _audioRecorder;
}
-(AVAudioPlayer *)audioPlayer{
    if (!_audioPlayer) {
        NSURL *url=[self getSavePath];
        NSError *error=nil;
        _audioPlayer=[[AVAudioPlayer alloc]initWithContentsOfURL:url error:&error];
        _audioPlayer.numberOfLoops=0;
        [_audioPlayer prepareToPlay];
        if (error) {
            NSLog(@"播放器：%@",error.localizedDescription);
            return nil;
        }
    }
    return _audioPlayer;
}
-(NSTimer *)timer{
    if (!_timer) {
        _timer=[NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(audioPowerChange) userInfo:nil repeats:YES];
    }
    return _timer;
}
- (void)audioPowerChange{
    [self.audioRecorder updateMeters];//更新测量值
    float power= [self.audioRecorder averagePowerForChannel:0];//取得第一个通道的音频，注意音频强度范围时-160到0
    CGFloat progress=(1.0/160.0)*(power+160.0);
    [self.audioPower setProgress:progress];
}
- (IBAction)playOne:(UIButton *)sender {
    [self playSoundEffect:@"123456.m4a"];
}

void soundCompleteCallback(SystemSoundID soundID,void * clientData){
    NSLog(@"播放完成...");
}

-(void)playSoundEffect:(NSString *)name{
    NSString *audioFile=[[NSBundle mainBundle] pathForResource:name ofType:nil];
    NSURL *fileUrl=[NSURL fileURLWithPath:audioFile];
    //1.获得系统声音ID
    SystemSoundID soundID=0;
    /**
     * inFileUrl:音频文件url
     * outSystemSoundID:声音id（此函数会将音效文件加入到系统音频服务中并返回一个长整形ID）
     */
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)(fileUrl), &soundID);
    //如果需要在播放完之后执行某些操作，可以调用如下方法注册一个播放完成回调函数
    AudioServicesAddSystemSoundCompletion(soundID, NULL, NULL, soundCompleteCallback, NULL);
    //2.播放音频
    AudioServicesPlaySystemSound(soundID);//播放音效
    AudioServicesPlayAlertSound(soundID);//播放音效并震动
}

- (IBAction)playRecorder:(UIButton *)sender {
    
    
   
}

- (IBAction)startRecorder:(id)sender {
    if (![self.audioRecorder isRecording]) {
        [self.audioRecorder record];//首次使用应用时如果调用record方法会询问用户是否允许使用麦克风
        self.timer.fireDate=[NSDate distantPast];
    }
}
- (IBAction)pauseRecorder:(id)sender {
    if ([self.audioRecorder isRecording]) {
        [self.audioRecorder pause];
        self.timer.fireDate=[NSDate distantFuture];
    }
}

- (IBAction)resetRecorder:(id)sender {
     [self startRecorder:sender];
}
- (IBAction)stopRecorder:(id)sender {
    [self.audioRecorder stop];
    self.timer.fireDate=[NSDate distantFuture];
    self.audioPower.progress=0.0;
}

#pragma mark - delegate
-(void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag{
    if (![self.audioPlayer isPlaying]) {
        [self.audioPlayer play];
    }
    NSLog(@"录音完成!");
}
@end
