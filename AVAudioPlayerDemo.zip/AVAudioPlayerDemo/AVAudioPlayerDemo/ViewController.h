//
//  ViewController.h
//  AVAudioPlayerDemo
//
//  Created by 方正 on 16/8/24.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

