//
//  TestProtocol.m
//  AVAudioPlayerDemo
//
//  Created by 方正 on 16/8/29.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import "TestProtocol.h"

@implementation TestProtocol

- (void)test
{
    __block __weak typeof(self)weakself = self;
    if ([self.delegate respondsToSelector:@selector(doSomeThingWithBlok:)]) {
         [self.delegate doSomeThingWithBlok:^(NSArray *array, NSError *error) {
             [weakself testTT];
         }];
    }
}

- (void)testTT
{
    
}
//- (void)setArray:(NSArray *)array
//{
//    
//}
- (NSMutableArray*)array
{
    if (_array==nil) {
        _array = [NSMutableArray new];
    }
    return _array;
}
@end
