//
//  PlayerViewController.m
//  AVAudioPlayerDemo
//
//  Created by 方正 on 16/8/29.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import "PlayerViewController.h"
#import <MediaPlayer/MediaPlayer.h>
@interface PlayerViewController ()

@property (nonatomic , strong) MPMoviePlayerController *movePlayer;
@end

@implementation PlayerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (MPMoviePlayerController*)movePlayer{
    if (!_movePlayer) {
        _movePlayer = [[MPMoviePlayerController alloc] initWithContentURL:nil];
    }
    return _movePlayer;
}
@end
