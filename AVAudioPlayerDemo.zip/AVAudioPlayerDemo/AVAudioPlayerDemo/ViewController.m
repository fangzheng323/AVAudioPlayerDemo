//
//  ViewController.m
//  AVAudioPlayerDemo
//
//  Created by 方正 on 16/8/24.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import "ViewController.h"
#import "TestProtocol.h"
#import <AVFoundation/AVFoundation.h>
#define kRsource @"郁可唯-远方.mp3"
@interface ViewController ()<AVAudioPlayerDelegate,AutoProtocolDelegate>

@property (weak, nonatomic) IBOutlet UILabel *musicName;

@property (weak, nonatomic) IBOutlet UILabel *singerName;

@property (weak, nonatomic) IBOutlet UIProgressView *musicProgress;
@property (weak, nonatomic) IBOutlet UIImageView *iconImage;

@property (weak, nonatomic) IBOutlet UISlider *silder;

@property (weak, nonatomic) IBOutlet UIView *view1;

@property (weak, nonatomic) IBOutlet UIView *view2;
@property (nonatomic, strong) AVAudioPlayer *audIoAPlayer;
@property (nonatomic, strong) NSTimer *timer;
@property (weak, nonatomic) IBOutlet UILabel *deMaXiYa;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.iconImage.image = [UIImage imageNamed:@"123"];
    self.musicName.text = @"郁可唯-远方";
    self.singerName.text = @"郁可唯";
    AVAudioSession *audioSession=[AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
    [audioSession setActive:YES error:nil];
   
    TestProtocol *test = [[TestProtocol alloc] init];
    test.delegate = self;
    [test test];
    
//    self.deMaXiYa.text =
    NSString *string = @"啦啦啦德玛西亚";
    
    NSInteger length = [string length];
    
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:string];
    [attString addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid|NSUnderlineStyleSingle) range:NSMakeRange(0, length)];
    [attString addAttribute:NSStrikethroughColorAttributeName value:[UIColor redColor] range:NSMakeRange(0, length)];
    [self.deMaXiYa setAttributedText:attString];
}


- (void)doSomeThingWithBlok:(block)block
{
    NSArray *arr = @[@"1",@"2",@"3"];
    
    block(arr,nil);
    //冒泡排序
    int a[12] = {30, 21, 13, 37, 43, 23, 34, 53, 66, 72, 99, 95};
    int index2 = 0;
    for (int index1 = 0; index1 < 12; index1++) {
        
        for (index2 = index1+1 ; index2 < 12; index2++) {
            // 取出第(n+1)个数与前者进行比较
            int variable = 0;
            if (a[index1] < a[index2]) {
                
                variable = a[index1];
                a[index1] = a[index2];
                a[index2] = variable;
                
            }}
        
    }
    
    for (int i = 0; i<12; i++) {
        NSLog(@"a===%d",a[i]);
    }
    
//    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES];
//    [arr sortedArrayUsingDescriptors:@[sort]];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    [self.view bringSubviewToFront:self.view1];
    [self.view bringSubviewToFront:self.view2];
}

- (NSTimer *)timer {
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(updateProgress) userInfo:nil repeats:YES];
    }
    return _timer;
}
- (IBAction)silderAction:(id)sender {
    UISlider *slider = (UISlider*)sender;
    _audIoAPlayer.volume = slider.value;

}

-(AVAudioPlayer*)audIoAPlayer {
    NSString *filePath = [[NSBundle mainBundle] pathForResource:kRsource ofType:nil];
    NSURL *url = [NSURL fileURLWithPath:filePath];
    if (!_audIoAPlayer) {
        
        _audIoAPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        _audIoAPlayer.numberOfLoops = 5;
        _audIoAPlayer.delegate = self;
        [_audIoAPlayer prepareToPlay];
    }
    return _audIoAPlayer;
}
- (void) play {
    if (![self.audIoAPlayer isPlaying]) {
        [self.audIoAPlayer play];
        self.timer.fireDate = [NSDate distantPast];
    }
}

- (void) pause {
    if ([self.audIoAPlayer isPlaying]) {
        [self.audIoAPlayer pause];
        self.timer.fireDate = [NSDate distantFuture];
    }
}
- (IBAction)playButton:(UIButton *)sender {
    
    if ([sender.titleLabel.text isEqualToString:@"播放"]) {
        [sender setTitle:@"暂停" forState:UIControlStateNormal];
        [self play];
    }else {
        [sender setTitle:@"播放" forState:UIControlStateNormal];
        [self pause];
    }
}

- (void)updateProgress {
    float progress = self.audIoAPlayer.currentTime / self.audIoAPlayer.duration;
    
    self.musicProgress.progress = progress;
}

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
    
    NSLog(@"player:%@   flag:%d ",player,flag);
}

@end
