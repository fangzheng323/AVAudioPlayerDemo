//
//  TestPlayerViewController.h
//  AVAudioPlayerDemo
//
//  Created by 方正 on 16/9/2.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestPlayerViewController : UIViewController

@end
